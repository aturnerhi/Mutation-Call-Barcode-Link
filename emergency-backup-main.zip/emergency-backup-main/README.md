# emergency-backup
Emergency Backup of all scripts in case of fire, flood, or internet crash

cd-hit is publicly available 

    Program written by Weizhong Li,  http://cd-hit.org
    
    
fasta36 is publicly available 

     Copyright (c) 1996, 1997, 1998, 1999, 2002, 2014, 2015 by William R. Pearson and The Rector & Visitors of the University of Virginia       
     /https://github.com/wrpearson/fasta36
     
Pipeline is written by me, unix script that calls open reading frame barcodes. All entries and file paths are custom, must be updated for each file name before run.
Calls dependencies python.py (which is mostly by me) that compares a line by line set of reads, forward and reverse. If the two reads of the same name have the same barcode, it returns them. 

mutation.py is currently in development, can only call the first mutation and exit, not helpful. Don't use yet. 
